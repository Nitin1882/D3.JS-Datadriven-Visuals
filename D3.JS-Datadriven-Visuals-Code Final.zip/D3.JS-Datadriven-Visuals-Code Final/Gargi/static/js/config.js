// API key
const API_KEY = "pk.eyJ1IjoiZ2FyZ2lwIiwiYSI6ImNrM3ZxZ3p3NzAxNTkzZ21qbTZ0cjh0MXkifQ.AXO5bqP74LyS_JfZchniGQ"